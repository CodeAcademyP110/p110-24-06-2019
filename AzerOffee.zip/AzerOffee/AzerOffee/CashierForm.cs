﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AzerOffee.Model;

namespace AzerOffee
{
    public partial class CashierForm : Form
    {
        private readonly AzerOffeeEntities _context;
        private readonly User _loggedUser;

        public CashierForm(User user)
        {
            InitializeComponent();
            _context = new AzerOffeeEntities();
            _loggedUser = user;
        }

        private void CashierForm_Load(object sender, EventArgs e)
        {
            //Show cashier name for welcoming
            txtWelcome.Text = $"Dear {_loggedUser.Firstname} {_loggedUser.Lastname}, Welcome.";

            //check if cashier logs in for the first time, show verifyPassword form
            if(!(bool)_loggedUser.HasVerifiedPassword)
            {
                new VerifyPasswordForm().ShowDialog();
            }
        }
    }
}
