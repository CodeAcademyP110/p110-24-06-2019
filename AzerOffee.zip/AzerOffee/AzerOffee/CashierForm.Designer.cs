﻿namespace AzerOffee
{
    partial class CashierForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtWelcome = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtWelcome
            // 
            this.txtWelcome.Dock = System.Windows.Forms.DockStyle.Top;
            this.txtWelcome.Font = new System.Drawing.Font("Century Gothic", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWelcome.Location = new System.Drawing.Point(0, 0);
            this.txtWelcome.Name = "txtWelcome";
            this.txtWelcome.Size = new System.Drawing.Size(854, 73);
            this.txtWelcome.TabIndex = 1;
            this.txtWelcome.Text = "Cashier";
            this.txtWelcome.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CashierForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 529);
            this.Controls.Add(this.txtWelcome);
            this.Name = "CashierForm";
            this.Text = "CashierForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.CashierForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label txtWelcome;
    }
}