﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AzerOffee.Model;
using static AzerOffee.Utilities.Hash;

namespace AzerOffee
{
    public partial class Form1 : Form
    {
        private readonly AzerOffeeEntities _context;

        public Form1()
        {
            InitializeComponent();
            _context = new AzerOffeeEntities();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if(username == string.Empty || password == string.Empty)
            {
                ShowError("Error", "Username and password fields should be filled");
                return;
            }

            //Authentication
            User user = _context.Users.FirstOrDefault(u => u.Username.ToLower() == username.ToLower());
            
            if(user == null)
            {
                ShowError("Error", "Username or password is invalid");
                return;
            }
           
            if(!CheckHash(user.Password, password))
            {
                ShowError("Error", "Username or password is invalid");
                return;
            }

            //Authorization
            switch (user.RoleId)
            {
                case 1:
                    new AdminForm().ShowDialog();
                    break;
                case 2:
                    new CashierForm(user).ShowDialog();
                    break;
                case 3:
                    new BaristaForm().ShowDialog();
                    break;
                default:
                    ShowError("Unknown login error", "Unknown error occurred. Please, contact Sardar!");
                    break;
            }
        }

        private void ShowError(string title, string content)
        {
            MessageBox.Show(content, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
